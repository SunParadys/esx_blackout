fx_version 'adamant'

game 'gta5'

description 'esx_blackout'

Author 'Sunparadys RP / https://discord.com/invite/nAahAnH9tm'

version '1.0'

client_scripts {
	'@es_extended/locale.lua',
	'client/main.lua'
}

server_scripts {
	'@es_extended/locale.lua',
	'server/main.lua'
}

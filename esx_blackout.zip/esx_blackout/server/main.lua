ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


ESX.RegisterUsableItem('bmode', function(source) --DB item bmode zum auslösen
	local xPlayer = ESX.GetPlayerFromId(source)
	TriggerClientEvent('esx_blackout:bmode', source)
	xPlayer.removeInventoryItem('bmode', 1) --bmode item wird gelöscht bei Verwendung
end)
